package com.boardgamelending.gamecatalogservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GameCatalogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
